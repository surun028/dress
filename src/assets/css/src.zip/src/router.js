import Vue from 'vue'

import VueRouter from 'vue-router'

Vue.use(VueRouter)

import Index from './components/Index.vue'
import Login from './components/Login.vue'
import Boss from './components/page/Boss.vue'
import Equipment from './components/page/Equipment.vue'
import Inform from './components/page/Inform.vue'
import User from './components/page/User.vue'
import Xinjian1 from './components/page/Xinjian1.vue'
import Xinjian2 from './components/page/Xinjian2.vue'
import Xinjian3 from './components/page/Xinjian3.vue'
import Xinjian4 from './components/page/Xinjian4.vue'

var routes = [
  { path: "/", component: Login },
  {path: "/index", component: Index, children: [
      { path: "/index/boss", component: Boss },
      { path: "/index/equipment", component: Equipment },
      { path: "/index/inform", component: Inform },
      { path: "/index/user", component: User },
      { path: "/index/xinjian1", component: Xinjian1 },
      { path: "/index/xinjian2", component: Xinjian2 },
      { path: "/index/xinjian3", component: Xinjian3 },
      { path: "/index/xinjian4", component: Xinjian4 },
    ]
  },
]

var router = new VueRouter({ routes, mode: 'history' })

export default router;