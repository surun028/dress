<template>
    <div class="index">
        <div class="top"></div>
        <ul class="list">
            <li><router-link to="/Index/Boss">管理员管理</router-link></li>
            <li><router-link to="/Index/User">用户管理</router-link></li>
            <li><router-link to="/Index/Inform">通知</router-link></li>
            <li><router-link to="/Index/Equipment">设备管理</router-link></li>
        </ul>
        <div>
        <router-view></router-view>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
.index .top{
    height: 2rem;
    background-color: #333;
}
.index .list{
    height: 43rem;
    background-color: #333;
    width: 10rem;
    border-top: 1px solid #000;
    color: #fff;
    float: left;
}
.index .list>li{
    width: 10rem;
    line-height: 2.5rem;
    background-color: #333;
    color: #fff;
    text-align: center;
    font-size: .7rem;
}
a{
    color: #fff;
    text-decoration:none;
}
</style>