<template>
    <div class="xinjian1">
        <h2>添加/修改管理员</h2>
        <div class="message">
      <div class="box">账号</div>
      <el-input v-model="input" id="inp"></el-input>
    </div>
    <div class="message">
      <div class="box">密码</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">确认密码</div>
      <el-input placeholder="确认密码" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">属性</div>
      <el-input placeholder="请输入属性" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">注册时间</div>
      <el-input placeholder="请输入密码" v-model="input1" show-password></el-input>
    </div>
    <div>
        <el-button type="primary">登录</el-button> <el-button>取消</el-button>
    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
.xinjian1{
    padding-left: 200px;
}
.xinjian1 h2{
    margin-top: 10px;
}
.xinjian1 .message {
  display: flex;
  align-items: center;
  margin-top: 1rem;
}
.xinjian1 .message .box {
  display: flex;
  align-items: center;
  width: 80px;
  text-align: right;
}
button {
  width: 6rem;
  margin-top: 1rem;
}
</style>