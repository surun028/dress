<template>
  <div class="xinjian1">
    <h2>添加用户</h2>
    <div class="message">
      <div class="box">账号</div>
      <el-input v-model="input" id="inp"></el-input>
    </div>
    <div class="message">
      <div class="box">密码</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">确认密码</div>
      <el-input placeholder="确认密码" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">电话</div>
      <el-input placeholder="请输入正确的手机号" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">邮箱</div>
      <el-input placeholder="请输入正确的邮箱地址" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">性别</div>
      <el-radio v-model="radio" label="1">男</el-radio>
      <el-radio v-model="radio" label="2">女</el-radio>
    </div>
    <div class="message">
      <div class="box">身份证号</div>
      <el-input placeholder="请输入正确的身份证号" v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">备注</div>
      <el-input v-model="input1" show-password></el-input>
    </div>

    <div>
      <el-button type="primary">发布</el-button>
      <el-button>返回</el-button>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        radio: '1'
      };
    }
  }
</script>
<style scoped>
.xinjian1 {
  padding-left: 200px;
}
.xinjian1 h2 {
  margin-top: 10px;
}
.xinjian1 .message {
  display: flex;
  align-items: center;
  margin-top: 1rem;
}
.xinjian1 .message .box {
  display: flex;
  align-items: center;
  width: 80px;
  text-align: right;
}
button {
  width: 6rem;
  margin-top: 1rem;
}
</style>