<template>
  <div class="xinjian1">
    <h2>添加/修改设备</h2>
    <div class="message">
      <div class="box">ip</div>
      <el-input v-model="input" id="inp"></el-input>
    </div>
    <div class="message">
      <div class="box">机房</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">编号</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">宽带</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">状态</div>
      <el-radio v-model="radio" label="1">空闲</el-radio>
      <el-radio v-model="radio" label="2">已出售</el-radio>
    </div>

    <div>
      <el-button type="primary">发布</el-button>
      <el-button>返回</el-button>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        radio: '1'
      };
    }
  }
</script>
<style scoped>
.xinjian1 {
  padding-left: 200px;
}
.xinjian1 h2 {
  margin-top: 10px;
}
.xinjian1 .message {
  display: flex;
  align-items: center;
  margin-top: 1rem;
}
.xinjian1 .message .box {
  display: flex;
  align-items: center;
  width: 80px;
  text-align: right;
}
button {
  width: 6rem;
  margin-top: 1rem;
}
</style>