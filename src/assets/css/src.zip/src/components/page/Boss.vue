<template>
  <div class="boss">
    <div class="top">设备列表页</div>
    <router-link to="/Index/Xinjian1">
      <button>新建</button>
    </router-link>

    <el-row :gutter="20">
      <el-col :span="3">
        <div class="grid-content bg-purple">序号 账号</div>
      </el-col>
      <el-col :span="3">
        <div class="grid-content bg-purple">电话</div>
      </el-col>
      <el-col :span="3">
        <div class="grid-content bg-purple">邮箱</div>
      </el-col>
      <el-col :span="3">
        <div class="grid-content bg-purple">性别</div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple">身份证号</div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple">备注</div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple">时间</div>
      </el-col>
      <el-col :span="3">
        <div class="grid-content bg-purple">
          <input type="text" placeholder="搜索账号名" />
        </div>
      </el-col>
      <el-col :span="22">
        <div class="grid-content bg-purple">
          <div id="data">暂无数据</div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.boss {
  padding-left: 200px;
  color: #897f7f;
}
.boss .top {
  font-size: 25px;
  margin-top: 1rem;
  color: black;
}
button {
  margin: 1rem 0;
  height: 2rem;
  width: 3rem;
  background-color: pink;
  border: none;
}
.el-row {
  margin-bottom: 20px;
}
.el-row:last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #fff;
}
.bg-purple {
  background: #fff;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
#data {
  line-height: 40px;
  border-top: 1px solid #efefef;
  border-bottom: 1px solid #efefef;
  text-align: center;
}
</style>