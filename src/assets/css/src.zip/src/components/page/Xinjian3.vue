<template>
    <div class="xinjian1">
        <h2>通知列表页</h2>
        <div class="message">
      <div class="box">题目</div>
      <el-input v-model="input" id="inp"></el-input>
    </div>
    <div class="message">
      <div class="box">内容</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div class="message">
      <div class="box">注册时间</div>
      <el-input v-model="input1" show-password></el-input>
    </div>
    <div>
        <el-button type="primary">发布</el-button> <el-button>返回</el-button>
    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
.xinjian1{
    padding-left: 200px;
}
.xinjian1 h2{
    margin-top: 10px;
}
.xinjian1 .message {
  display: flex;
  align-items: center;
  margin-top: 1rem;
}
.xinjian1 .message .box {
  display: flex;
  align-items: center;
  width: 80px;
  text-align: right;
}
button {
  width: 6rem;
  margin-top: 1rem;
}
</style>