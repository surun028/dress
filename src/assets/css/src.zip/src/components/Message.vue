<template>
    <div class="message">
        {{title}}
    </div>
</template>
<script>
export default {
    props:['title']
}
</script>
<style scoped>
  .message{
      width:420px;
      height:200px;
      border-radius:5px;
      position:fixed;
      left:0;
      top: 0;
      bottom:0;
      right:0;
      margin:auto;
      z-index: 9999;
      background: #fff;;
  }
</style>