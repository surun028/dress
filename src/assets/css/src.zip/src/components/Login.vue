<template>
  <div class="login">
    <div class="message">
      <div class="box">选择</div>
      <el-select v-model="value" placeholder="请选择">
      <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
    </el-select>
    </div>
    
    <div class="message">
      <div class="box">账号</div>
      <el-input v-model="input" placeholder="请输入内容" id="inp"></el-input>
    </div>
    <div class="message">
      <div class="box">密码</div>
      <el-input placeholder="请输入密码" v-model="input1" show-password></el-input>
    </div>

    <div>
      <router-link to="/Index">
        <el-button type="primary" @click="login">登录</el-button>
      </router-link>  <el-button>取消</el-button>
    </div>
  
  </div>
</template>

<script>
export default {
  data() {
    return {
      options: [
        {
          value: "选项1",
          label: "超级管理员"
        },
        {
          value: "选项2",
          label: "普通管理员"
        },
        {
          value: "选项3",
          label: "用户"
        }
      ],
      value: "",
      input: "",
      input1: ""
    };
  },
   methods: {
    login() {
      this.$router.push("/gly");
    }
  },
};
</script>
<style scoped>
.login {
  width: 20rem;
  height: 15rem;
  background-color: rgba(0, 0, 0, 0.1);
  margin: 10rem auto;
  padding: 2rem 2rem;
}
.login .message {
  display: flex;
  align-items: center;
  width: 20rem;
  margin-bottom: 1rem;
}
.login .message .box {
  display: flex;
  align-items: center;
  width: 3rem;
}
#inp {
  position: absolute;
  display: inline-block;
}
.el-input {
  display: inline-block;
}
button {
  width: 6rem;
  margin-top: 1rem;
}
</style>