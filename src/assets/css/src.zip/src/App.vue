<template>
  <div>
     <div class="main">
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
// import Login from "./components/Login";

export default {
  // components: {
  //   Login
  // }
};
</script>
<style>
*{
  margin: 0;
  padding: 0;
}
</style>